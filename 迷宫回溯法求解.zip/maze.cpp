#include<iostream>
#include"maze.h"
using namespace std;

int main()
{
	Point start(2, 0), exit(5, 10);
	Maze maze(start, exit);
	if (!maze.readMaze("map.txt"))
		return 1;
	maze.findPath();
	maze.showPath();
	maze.showMap();
	system("pause");
	return 0;
}